// Reusable function to render a Handlebars template and insert it into the DOM
function renderTemplate(templateName, data, containerId) {
    var template = Handlebars.templates[templateName];
    var renderedHtml = template(data);
    document.getElementById(containerId).innerHTML = renderedHtml;
}


// Retrieve and parse the selected week from localStorage
let storedWeek = localStorage.getItem('Week View');
let currentWeek = storedWeek ? parseInt(storedWeek) : 0; // Default to 0 if no selection
let mySearch = localStorage.getItem('Search Engine')
let username = localStorage.getItem('Name')
let userProgressID = localStorage.getItem('UserProgressID')
let percentcompleted = Math.round((userProgressID / 73) * 100)
let toggleBookmarkStored = parseInt(localStorage.getItem('toggleBookmark'))
let toggleBookmark = toggleBookmarkStored ? parseInt(toggleBookmarkStored) : 0;
let toggleDateStored = parseInt(localStorage.getItem('toggleDate'));
let toggleDate = toggleDateStored ? parseInt(toggleDateStored) : 0;
let toggleTimeStored = parseInt(localStorage.getItem('toggleTime'));
let toggleTime = toggleTimeStored ? parseInt(toggleTimeStored) : 0;
let toggleNameStored = parseInt(localStorage.getItem('toggleName'));
let toggleName = toggleNameStored ? parseInt(toggleNameStored) : 0;
var today = new Date();
var date = today.getMonth() + '/' + (today.getDate() + 1) + '/' + today.getFullYear();
var time = today.toLocaleString('en-US', {
    hour: 'numeric',
    minute: 'numeric',
    hour12: true
});

let data = {
    week,
    mySearch,
    username,
    userProgressID,
    percentcompleted,
    toggleBookmark,
    date,
    time,
    toggleDate,
    toggleTime,
    toggleName
};


Handlebars.registerHelper('eq', function(a, b) {
    return a === b;
});

// Register a Handlebars helper to compare the current week with the weekNumber
Handlebars.registerHelper('ifCurrentWeek', function(weekNumber, options) {
    if (currentWeek === weekNumber) {
        return options.fn(this);
    }
});

// Attach event listeners when DOM content is loaded
document.addEventListener('DOMContentLoaded', function() {
    const settingsItems = document.getElementsByClassName('settings-individual-item');

    for (const item of settingsItems) {
        item.addEventListener('click', function(event) {
            if (event.target.classList.contains("week-selection-link")) {
                event.preventDefault();
                var clickedWeekText = event.target.textContent.trim();
                localStorage.setItem('Week View', clickedWeekText);
                console.log('Selected week:', clickedWeekText);
                currentWeek = parseInt(clickedWeekText);
                renderTemplate("week-content-template", data, "week-content");
                location.reload();
            } else if (event.target.classList.contains("engine-selection")) {
                event.preventDefault();
                var clickedEngine = event.target.textContent.trim();
                localStorage.setItem('Search Engine', clickedEngine);
                console.log('Selected Search Engine:', clickedEngine);
                renderTemplate("search-template", data, "search");
                location.reload();
            } else if (event.target.tagName === 'A') {
                handleToggleEvent(event.target);
            }
        });
    }
    const submitButton = document.querySelector('.name-button');
    const inputElement = document.querySelector('.name-form');

    // Add an event listener to the form for when it's submitted
    submitButton.addEventListener('click', function(event) {
        event.preventDefault(); // Prevent the default form submission

        var nameInput = inputElement.value; // Get the value from the input
        localStorage.setItem('Name', nameInput);

        console.log('The User name is', nameInput);

        // Update the currentWeek variable after setting it in localStorage
        let username = localStorage.getItem('Name', nameInput)
        renderTemplate("search-template", data, "search");
        location.reload()
    });


    document.getElementById('week-content').addEventListener('click', function(event) {
        if (event.target.classList.contains('week-content-link')) {
            handleWeekContentClick(event.target.dataset.progress);
        }
    });

    let isFirstVisit = localStorage.getItem('firstVisit') === null;

    if (isFirstVisit) {
        // Redirect the user to the setup.html page for first-time setup
        window.location.href = 'setup.html';
    }

    const resetButton = document.querySelector('.btn-danger');

    resetButton.addEventListener('click', function() {
        localStorage.clear();
        alert('Extension has been reset, your CS50x course was untouched');
        location.reload()
    });
});

function handleToggleEvent(target) {
    const toggleType = target.classList.contains("bookmark-toggle") ?
        "Bookmark" :
        target.classList.contains("date-toggle") ?
        "Date" :
        target.classList.contains("time-toggle") ?
        "Time" :
        target.classList.contains("name-toggle") ?
        "Name" :
        "";

    if (toggleType) {
        const toggleKey = `toggle${toggleType}`;
        const toggleValue = localStorage.getItem(toggleKey) === "1" ? "0" : "1";
        localStorage.setItem(toggleKey, toggleValue);
        target.setAttribute("aria-pressed", toggleValue === "1" ? "true" : "false");
        console.log(`Toggle ${toggleType}:`, toggleValue);
        let isFirstVisit = localStorage.getItem('firstVisit') === null;
        if (!isFirstVisit) {
            setTimeout(function() {
                location.reload();
            }, 100);
        }
    }
}

function handleWeekContentClick(clickedContent) {
    localStorage.setItem('UserProgressID', clickedContent);
    console.log('User progress ID:', clickedContent);
    clickedContent = parseInt(clickedContent);
    renderTemplate("week-content-template", data, "week-content");
    setTimeout(function() {
        location.reload();
    }, 100);
}


document.addEventListener('DOMContentLoaded', function() {
    const colorSquareLinks = document.querySelectorAll('.color-square-link');
    const colorPicker = document.getElementById('colorPicker');
    const confirmColorBtn = document.getElementById('confirmColorBtn');

    // Attach event listeners to color square links
    colorSquareLinks.forEach(link => {
        link.addEventListener('click', function(event) {
            event.preventDefault();
            const color = link.getAttribute('data-color');
            setBackground(color);
        });
    });

    // Attach event listener to confirm color button
    confirmColorBtn.addEventListener('click', function() {
        const customColor = colorPicker.value;
        setBackground(customColor);
    });

    // Check and apply stored background color
    const storedColor = localStorage.getItem('backgroundColor');
    if (storedColor) {
        document.body.style.backgroundColor = storedColor;
    }

    const finishSetupButton = document.getElementById('finishSetupButton');

    finishSetupButton.addEventListener('click', function() {
        // Set isFirstVisit to false
        localStorage.setItem('firstVisit', 'false');

        // Redirect to index.html
        window.location.href = 'index.html';
    });
});

// Function to set the background color and save it to localStorage
function setBackground(color) {
    document.body.style.backgroundColor = color;
    localStorage.setItem('backgroundColor', color);
}


setTimeout(function() {
    location.reload();
}, 60000);



renderTemplate("settings-templates", data, "settings");




renderTemplate("week-content-template", data, "week-content");

renderTemplate("search-template", data, "search");

renderTemplate("topright-template", data, "topright");