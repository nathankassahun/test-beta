// Mini database of all the links to cs50 content per week
const week = [{
  weekNumber: 0,
  weekLabel: "Scratch",
  content: [{
      label: "Overview",
      progressID: 1,
      requiredProgress: 0,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@a8730f85a9a94d41a784a58c4b6d8bdc/block-v1:HarvardX+CS50+X+type@vertical+block@31304400fd444ea9860a8833cce5c248"
    },
    {
      label: "Lecture",
      progressID: 2,
      requiredProgress: 1,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@a8730f85a9a94d41a784a58c4b6d8bdc/block-v1:HarvardX+CS50+X+type@vertical+block@1f7492083e40484ab19113154b509e6f"
    },
    {
      label: "Scratch",
      progressID: 3,
      requiredProgress: 2,
      url: "https://cs50.harvard.edu/x/2023/psets/0/scratch/"
    },
  ],
  bookmarks: [{
      label: "CS50x Homepage",
      url: "https://cs50.harvard.edu/x/2023/",
      favicon: "./ui-elements/harvard-logo.png"
    },
    {
      label: "CS50x Gradebook",
      url: "https://cs50.me/cs50x",
      favicon: "./ui-elements/harvard-logo.png"
    },
    {
      label: "Scratch",
      url: "https://scratch.mit.edu",
      favicon: "./ui-elements/scratch.png"
    },
  ],
  instruction: "<h3>Week 0</h3><ul><li>Overview</li><li>Lecture</li><li>Scratch</li></ul>",
},

{
  weekNumber: 1,
  weekLabel: "C",
  content: [{
      label: "Overview",
      progressID: 4,
      requiredProgress: 3,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@376b3893fe2a45f4b3fec7335b3c8640/block-v1:HarvardX+CS50+X+type@vertical+block@207e2527aef54d78a423fd22e18d93ee"
    },
    {
      label: "Lecture",
      progressID: 5,
      requiredProgress: 4,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@376b3893fe2a45f4b3fec7335b3c8640/block-v1:HarvardX+CS50+X+type@vertical+block@2f822eb11b72487584baa444ab204cd6"
    },
    {
      label: "Section",
      progressID: 6,
      requiredProgress: 5,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@376b3893fe2a45f4b3fec7335b3c8640/block-v1:HarvardX+CS50+X+type@vertical+block@43570fda10404cc1b7f948c35647adcb"
    },
    {
      label: "Shorts",
      progressID: 7,
      requiredProgress: 6,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@376b3893fe2a45f4b3fec7335b3c8640/block-v1:HarvardX+CS50+X+type@vertical+block@1cda965a3f6044a09e256fa6e6b18c1d"
    },
    {
      label: "Lab 1",
      progressID: 8,
      requiredProgress: 7,
      url: "https://cs50.harvard.edu/x/2023/labs/1/"
    },
    {
      label: "Hello",
      progressID: 9,
      requiredProgress: 8,
      url: "https://cs50.harvard.edu/x/2023/psets/1/hello/"
    },
    {
      label: "Mario (less)",
      progressID: 10,
      requiredProgress: 9,
      url: "https://cs50.harvard.edu/x/2023/psets/1/mario/less/"
    },
    {
      label: "Mario (more)",
      progressID: 10,
      requiredProgress: 9,
      url: "https://cs50.harvard.edu/x/2023/psets/1/mario/more/"
    },
    {
      label: "Cash",
      progressID: 11,
      requiredProgress: 10,
      url: "https://cs50.harvard.edu/x/2023/psets/1/cash/"
    },
    {
      label: "Credit",
      progressID: 11,
      requiredProgress: 10,
      url: "https://cs50.harvard.edu/x/2023/psets/1/credit/"
    },
  ],
  bookmarks: [{
      label: "CS50x Homepage",
      url: "https://cs50.harvard.edu/x/2023/",
      favicon: "./ui-elements/harvard-logo.png"
    },
    {
      label: "CS50x Gradebook",
      url: "https://cs50.me/cs50x",
      favicon: "./ui-elements/harvard-logo.png"
    },
    {
      label: "CS50 Manual Pages",
      url: "https://manual.cs50.io/",
      favicon: "./ui-elements/cs50-manual.png"
    },
    {
      label: "VS Code",
      url: "https://cs50.dev/",
      favicon: "./ui-elements/vscode.png"
    },
    {
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/home",
      favicon: "./ui-elements/cs50-edx.png"
    },
  ],
  instruction: "<h3>Week 1</h3><ul><li>Overview</li><li>Lecture</li><li>Section</li><li>Shorts</li><li>Lab 1</li><li>Problem Set<ul><li>Hello</li><li>Mario (less) or Mario (more)</li><li>Cash or Credit</li></ul></li></ul>",
},
{
  weekNumber: 2,
  weekLabel: "Arrays",
  content: [{
      label: "Overview",
      progressID: 12,
      requiredProgress: 11,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@bbb214a2ef2549e68d7fec9fd5667b7d/block-v1:HarvardX+CS50+X+type@vertical+block@ec5c719fbd6349d09a10ddaafb03af31"
    },
    {
      label: "Lecture",
      progressID: 13,
      requiredProgress: 12,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@bbb214a2ef2549e68d7fec9fd5667b7d/block-v1:HarvardX+CS50+X+type@vertical+block@a7adabb9fd174d8690e597ac83e1803e"
    },
    {
      label: "Section",
      progressID: 14,
      requiredProgress: 13,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@bbb214a2ef2549e68d7fec9fd5667b7d/block-v1:HarvardX+CS50+X+type@vertical+block@7ca658e34307439f9d8d545603ff710c"
    },
    {
      label: "Shorts",
      progressID: 15,
      requiredProgress: 14,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@bbb214a2ef2549e68d7fec9fd5667b7d/block-v1:HarvardX+CS50+X+type@vertical+block@45981f6851374eb98aeb3d39c616a560"
    },
    {
      label: "Lab 2",
      progressID: 16,
      requiredProgress: 15,
      url: "https://cs50.harvard.edu/x/2023/labs/2/"
    },
    {
      label: "Readability",
      progressID: 17,
      requiredProgress: 16,
      url: "https://cs50.harvard.edu/x/2023/psets/2/readability/"
    },
    {
      label: "Bulbs",
      progressID: 18,
      requiredProgress: 17,
      url: "https://cs50.harvard.edu/x/2023/psets/2/bulbs/"
    },
    {
      label: "Caesar",
      progressID: 18,
      requiredProgress: 17,
      url: "https://cs50.harvard.edu/x/2023/psets/2/caesar/"
    },
    {
      label: "Substitution",
      progressID: 18,
      requiredProgress: 17,
      url: "https://cs50.harvard.edu/x/2023/psets/2/substitution/"
    },
    {
      label: "Wordle50",
      progressID: 18,
      requiredProgress: 17,
      url: "https://cs50.harvard.edu/x/2023/psets/2/wordle50/"
    },
  ],
  bookmarks: [{
      label: "CS50x Homepage",
      url: "https://cs50.harvard.edu/x/2023/",
      favicon: "./ui-elements/harvard-logo.png"
    },
    {
      label: "CS50x Gradebook",
      url: "https://cs50.me/cs50x",
      favicon: "./ui-elements/harvard-logo.png"
    },
    {
      label: "CS50 Manual Pages",
      url: "https://manual.cs50.io/",
      favicon: "./ui-elements/cs50-manual.png"
    },
    {
      label: "VS Code",
      url: "https://cs50.dev/",
      favicon: "./ui-elements/vscode.png"
    },
    {
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/home",
      favicon: "./ui-elements/cs50-edx.png"
    },
  ],
  instruction: "<h3>Week 2</h3><ul><li>Overview</li><li>Lecture</li><li>Section</li><li>Shorts</li><li>Lab 2</li><li>Problem Set<ul><li>Readability</li><li>One of: <br>Bulbs (less) <br>or Caesar (less) <br>or Substitution (more) <br>or Wordle50  (more)</li></ul></li></ul>",
},
{
  weekNumber: 3,
  weekLabel: "Algorithms",
  content: [{
      label: "Overview",
      progressID: 19,
      requiredProgress: 18,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@ea2b55b5e6884be0b9c6764efb3341b7/block-v1:HarvardX+CS50+X+type@vertical+block@a4fa564ff2c04130bb5ba84ef2bb7ff0"
    },
    {
      label: "Lecture ",
      progressID: 20,
      requiredProgress: 19,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@ea2b55b5e6884be0b9c6764efb3341b7/block-v1:HarvardX+CS50+X+type@vertical+block@e0097038ab30433c98177b7fa07ffa1e"
    },
    {
      label: "Section",
      progressID: 21,
      requiredProgress: 20,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@ea2b55b5e6884be0b9c6764efb3341b7/block-v1:HarvardX+CS50+X+type@vertical+block@b48994fa9473498e852f855bf13bbb49"
    },
    {
      label: "Shorts",
      progressID: 22,
      requiredProgress: 21,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@ea2b55b5e6884be0b9c6764efb3341b7/block-v1:HarvardX+CS50+X+type@vertical+block@415a5418c46541069284580ecabf85e0"
    },
    {
      label: "Lab 3",
      progressID: 23,
      requiredProgress: 22,
      url: "https://cs50.harvard.edu/x/2023/labs/3/"
    },
    {
      label: "Plurality",
      progressID: 24,
      requiredProgress: 23,
      url: "https://cs50.harvard.edu/x/2023/psets/3/plurality/"
    },
    {
      label: "Runoff",
      progressID: 25,
      requiredProgress: 24,
      url: "https://cs50.harvard.edu/x/2023/psets/3/runoff/"
    },
    {
      label: "Tideman",
      progressID: 25,
      requiredProgress: 24,
      url: "https://cs50.harvard.edu/x/2023/psets/3/tideman/"
    },
  ],
  bookmarks: [{
      label: "CS50x Homepage",
      url: "https://cs50.harvard.edu/x/2023/",
      favicon: "./ui-elements/harvard-logo.png"
    },
    {
      label: "CS50x Gradebook",
      url: "https://cs50.me/cs50x",
      favicon: "./ui-elements/harvard-logo.png"
    },
    {
      label: "CS50 Manual Pages",
      url: "https://manual.cs50.io/",
      favicon: "./ui-elements/cs50-manual.png"
    },
    {
      label: "VS Code",
      url: "https://cs50.dev/",
      favicon: "./ui-elements/vscode.png"
    },
    {
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/home",
      favicon: "./ui-elements/cs50-edx.png"
    },
  ],
  instruction: "<h3>Week 3</h3><ul><li>Overview</li><li>Lecture</li><li>Section</li><li>Shorts</li><li>Lab 3</li><li>Problem Set<ul><li>Plurality</li><li>Runoff or Tideman</li></ul></li></ul>",
},
{
  weekNumber: 4,
  weekLabel: "Memory",
  content: [{
      label: "Overview",
      progressID: 26,
      requiredProgress: 25,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@65cdc65777b4421781a6197887d12fd7/block-v1:HarvardX+CS50+X+type@vertical+block@83496dc9b595438997f733f71807f43b"
    },
    {
      label: "Lecture",
      progressID: 27,
      requiredProgress: 26,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@65cdc65777b4421781a6197887d12fd7/block-v1:HarvardX+CS50+X+type@vertical+block@6288c1bec3984cbcaa6f24988ba1234f"
    },
    {
      label: "Section",
      progressID: 28,
      requiredProgress: 27,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@65cdc65777b4421781a6197887d12fd7/block-v1:HarvardX+CS50+X+type@vertical+block@398376840530479882a487a1f0baae33"
    },
    {
      label: "Shorts",
      progressID: 29,
      requiredProgress: 28,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@65cdc65777b4421781a6197887d12fd7/block-v1:HarvardX+CS50+X+type@vertical+block@a86cf577749c46f4b26e5cfe3f7d9ed3"
    },
    {
      label: "Lab 4",
      progressID: 30,
      requiredProgress: 29,
      url: "https://cs50.harvard.edu/x/2023/labs/4/"
    },
    {
      label: "Filter (less)",
      progressID: 31,
      requiredProgress: 30,
      url: "https://cs50.harvard.edu/x/2023/psets/4/filter/less/"
    },
    {
      label: "Filter (more)",
      progressID: 31,
      requiredProgress: 30,
      url: "https://cs50.harvard.edu/x/2023/psets/4/filter/more/"
    },
    {
      label: "Recover",
      progressID: 32,
      requiredProgress: 31,
      url: "https://cs50.harvard.edu/x/2023/psets/4/recover/"
    },
    {
      label: "Reverse",
      progressID: 32,
      requiredProgress: 31,
      url: "https://cs50.harvard.edu/x/2023/psets/4/reverse/"
    },
  ],
  bookmarks: [{
      label: "CS50x Homepage",
      url: "https://cs50.harvard.edu/x/2023/",
      favicon: "./ui-elements/harvard-logo.png"
    },
    {
      label: "CS50x Gradebook",
      url: "https://cs50.me/cs50x",
      favicon: "./ui-elements/harvard-logo.png"
    },
    {
      label: "CS50 Manual Pages",
      url: "https://manual.cs50.io/",
      favicon: "./ui-elements/cs50-manual.png"
    },
    {
      label: "VS Code",
      url: "https://cs50.dev/",
      favicon: "./ui-elements/vscode.png"
    },
    {
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/home",
      favicon: "./ui-elements/cs50-edx.png"
    },
  ],
  instruction: "<h3>Week 4</h3><ul><li>Overview</li><li>Lecture</li><li>Section</li><li>Shorts</li><li>Lab 4</li><li>Problem Set<ul><li>Filter (less) or Filter (more)</li><li>Recover or Reverse</li></ul></li></ul>",
},
{
  weekNumber: 5,
  weekLabel: "Data Structures",
  content: [{
      label: "Overview",
      progressID: 33,
      requiredProgress: 32,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@777300888dd848568a9c37e53cbc3246/block-v1:HarvardX+CS50+X+type@vertical+block@57d2b52d29e84423a0ed933ad23b227a"
    },
    {
      label: "Lecture ",
      progressID: 34,
      requiredProgress: 33,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@777300888dd848568a9c37e53cbc3246/block-v1:HarvardX+CS50+X+type@vertical+block@48aabbc7d0194f44be4e7c0b602b2c92"
    },
    {
      label: "Section",
      progressID: 35,
      requiredProgress: 34,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@777300888dd848568a9c37e53cbc3246/block-v1:HarvardX+CS50+X+type@vertical+block@c2a17704ee1248c5ba1c64d8d4969578"
    },
    {
      label: "Shorts",
      progressID: 36,
      requiredProgress: 35,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@777300888dd848568a9c37e53cbc3246/block-v1:HarvardX+CS50+X+type@vertical+block@caa3356d0d2e4250b1c85cc1d14efe8e"
    },
    {
      label: "Lab 5",
      progressID: 37,
      requiredProgress: 36,
      url: "https://cs50.harvard.edu/x/2023/labs/5/"
    },
    {
      label: "Speller",
      progressID: 38,
      requiredProgress: 37,
      url: "https://cs50.harvard.edu/x/2023/psets/5/speller/"
    },
  ],
  bookmarks: [{
      label: "CS50x Homepage",
      url: "https://cs50.harvard.edu/x/2023/",
      favicon: "./ui-elements/harvard-logo.png"
    },
    {
      label: "CS50x Gradebook",
      url: "https://cs50.me/cs50x",
      favicon: "./ui-elements/harvard-logo.png"
    },
    {
      label: "CS50 Manual Pages",
      url: "https://manual.cs50.io/",
      favicon: "./ui-elements/cs50-manual.png"
    },
    {
      label: "VS Code",
      url: "https://cs50.dev/",
      favicon: "./ui-elements/vscode.png"
    },
    {
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/home",
      favicon: "./ui-elements/cs50-edx.png"
    },
  ],
  instruction: "<h3>Week 5</h3><ul><li>Overview</li><li>Lecture</li><li>Section</li><li>Shorts</li><li>Lab 5</li><li>Problem Set<ul><li>Speller</li></ul></li></ul>"
},
{
  weekNumber: 6,
  weekLabel: "Python",
  content: [{
      label: "Overview",
      progressID: 39,
      requiredProgress: 38,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@0d0d972b09b94da1aa23e991ef331afd/block-v1:HarvardX+CS50+X+type@vertical+block@b6f3d34ee94748bb9bfe4dd4389349ce"
    },
    {
      label: "Lecture",
      progressID: 40,
      requiredProgress: 39,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@0d0d972b09b94da1aa23e991ef331afd/block-v1:HarvardX+CS50+X+type@vertical+block@f66d736431464e56af505ecc7801ee6b"
    },
    {
      label: "Section",
      progressID: 41,
      requiredProgress: 40,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@0d0d972b09b94da1aa23e991ef331afd/block-v1:HarvardX+CS50+X+type@vertical+block@b1a16c14993c4571811b897b0e16c738"
    },
    {
      label: "Shorts",
      progressID: 42,
      requiredProgress: 41,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@0d0d972b09b94da1aa23e991ef331afd/block-v1:HarvardX+CS50+X+type@vertical+block@f5768c307d7b42868c734761931d53f0"
    },
    {
      label: "Lab 6",
      progressID: 43,
      requiredProgress: 42,
      url: "https://cs50.harvard.edu/x/2023/labs/6/"
    },
    {
      label: "Hello (Python)",
      progressID: 44,
      requiredProgress: 43,
      url: "https://cs50.harvard.edu/x/2023/psets/6/hello/"
    },
    {
      label: "Mario (Python less)",
      progressID: 45,
      requiredProgress: 44,
      url: "https://cs50.harvard.edu/x/2023/psets/6/mario/less/"
    },
    {
      label: "Mario (Python more)",
      progressID: 45,
      requiredProgress: 44,
      url: "https://cs50.harvard.edu/x/2023/psets/6/mario/more/"
    },
    {
      label: "Cash (Python)",
      progressID: 46,
      requiredProgress: 45,
      url: "https://cs50.harvard.edu/x/2023/psets/6/cash/"
    },
    {
      label: "Credit (Python)",
      progressID: 46,
      requiredProgress: 45,
      url: "https://cs50.harvard.edu/x/2023/psets/6/credit/"
    },
    {
      label: "Readability (Python)",
      progressID: 47,
      requiredProgress: 46,
      url: "https://cs50.harvard.edu/x/2023/psets/6/readability/"
    },
    {
      label: "DNA",
      progressID: 48,
      requiredProgress: 47,
      url: "https://cs50.harvard.edu/x/2023/psets/6/dna/"
    },
  ],
  bookmarks: [{
      label: "CS50x Homepage",
      url: "https://cs50.harvard.edu/x/2023/",
      favicon: "./ui-elements/harvard-logo.png"
    },
    {
      label: "CS50x Gradebook",
      url: "https://cs50.me/cs50x",
      favicon: "./ui-elements/harvard-logo.png"
    },
    {
      label: "VS Code",
      url: "https://cs50.dev/",
      favicon: "./ui-elements/vscode.png"
    },
    {
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/home",
      favicon: "./ui-elements/cs50-edx.png"
    },
  ],
  instruction: "<h3>Week 6</h3><ul><li>Overview</li><li>Lecture</li><li>Section</li><li>Shorts</li><li>Lab 6</li><li>Problem Set<ul><li>Hello (Python)</li><li>Mario (Python less) or Mario (more)</li><li>Cash (Python) or Credit (Python)</li><li>Readability (Python)</li><li>DNA</li></ul></li></ul>",
},
{
  weekNumber: 7,
  weekLabel: "SQL",
  content: [{
      label: "Overview",
      progressID: 49,
      requiredProgress: 48,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@ba11fd5c31a34e47b7af3708832162c5/block-v1:HarvardX+CS50+X+type@vertical+block@8b295a7f30e84e0c8242769dc4fc5a96"
    },
    {
      label: "Lecture ",
      progressID: 50,
      requiredProgress: 49,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@ba11fd5c31a34e47b7af3708832162c5/block-v1:HarvardX+CS50+X+type@vertical+block@5b3e7bf7be95404294c7ed89ba422403"
    },
    {
      label: "Section",
      progressID: 51,
      requiredProgress: 50,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@ba11fd5c31a34e47b7af3708832162c5/block-v1:HarvardX+CS50+X+type@vertical+block@0444058b1cc646cca051a99ba5edeb73"
    },
    {
      label: "Shorts",
      progressID: 52,
      requiredProgress: 51,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@ba11fd5c31a34e47b7af3708832162c5/block-v1:HarvardX+CS50+X+type@vertical+block@aa8ec0faea3d49eb837655194462a902"
    },
    {
      label: "Lab 7",
      progressID: 53,
      requiredProgress: 52,
      url: "https://cs50.harvard.edu/x/2023/labs/7/"
    },
    {
      label: "Movies",
      progressID: 54,
      requiredProgress: 53,
      url: "https://cs50.harvard.edu/x/2023/psets/7/movies/"
    },
    {
      label: "Fiftyville",
      progressID: 55,
      requiredProgress: 54,
      url: "https://cs50.harvard.edu/x/2023/psets/7/fiftyville/"
    },
  ],
  bookmarks: [{
      label: "CS50x Homepage",
      url: "https://cs50.harvard.edu/x/2023/",
      favicon: "./ui-elements/harvard-logo.png"
    },
    {
      label: "CS50x Gradebook",
      url: "https://cs50.me/cs50x",
      favicon: "./ui-elements/harvard-logo.png"
    },
    {
      label: "VS Code",
      url: "https://cs50.dev/",
      favicon: "./ui-elements/vscode.png"
    },
    {
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/home",
      favicon: "./ui-elements/cs50-edx.png"
    },
    {
      label: "W3Schools SQL",
      url: "https://www.w3schools.com/sql/",
      favicon: "./ui-elements/w3schools.png"
    }
  ],
  instruction: "<h3>Week 7</h3><ul><li>Overview</li><li>Lecture</li><li>Section</li><li>Shorts</li><li>Lab 7</li><li>Problem Set<ul><li>Movies</li><li>Fiftyville</li></ul></li></ul>",
},
{
  weekNumber: 8,
  weekLabel: "HTML, CSS, JavaScript",
  content: [{
      label: "Cybersecurity Overview",
      progressID: 56,
      requiredProgress: 55,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@5b2ceb61052c4e15b7cbc30bd86ab242/block-v1:HarvardX+CS50+X+type@vertical+block@eaae1f2aa20e45d2a1b911c0d6cb66bc"
    },
    {
      label: "Cybersecurity Lecture",
      progressID: 57,
      requiredProgress: 56,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@5b2ceb61052c4e15b7cbc30bd86ab242/block-v1:HarvardX+CS50+X+type@vertical+block@e6f7051d0c6c420280f89f5e5da20b14"
    },
    {
      label: "Overview",
      progressID: 58,
      requiredProgress: 57,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@638af9550b164582b9bc6c1b0e562881/block-v1:HarvardX+CS50+X+type@vertical+block@b01c03067cfb495f891a1a7b4c645a53"
    },
    {
      label: "Lecture ",
      progressID: 59,
      requiredProgress: 58,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@638af9550b164582b9bc6c1b0e562881/block-v1:HarvardX+CS50+X+type@vertical+block@63f49aa6b56b4262a0a16617dd7c5415"
    },
    {
      label: "Section",
      progressID: 60,
      requiredProgress: 59,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@638af9550b164582b9bc6c1b0e562881/block-v1:HarvardX+CS50+X+type@vertical+block@6cd85cf877774bafaaa8122eab98b272"
    },
    {
      label: "Shorts",
      progressID: 61,
      requiredProgress: 60,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@638af9550b164582b9bc6c1b0e562881/block-v1:HarvardX+CS50+X+type@vertical+block@09ec85bebc6d441b82c5a4f517a930ec"
    },
    {
      label: "Lab 8",
      progressID: 62,
      requiredProgress: 61,
      url: "https://cs50.harvard.edu/x/2023/labs/8/"
    },
    {
      label: "Homepage",
      progressID: 63,
      requiredProgress: 62,
      url: "https://cs50.harvard.edu/x/2023/psets/8/homepage/"
    },
  ],
  bookmarks: [{
      label: "CS50x Homepage",
      url: "https://cs50.harvard.edu/x/2023/",
      favicon: "./ui-elements/harvard-logo.png"
    },
    {
      label: "CS50x Gradebook",
      url: "https://cs50.me/cs50x",
      favicon: "./ui-elements/harvard-logo.png"
    },
    {
      label: "VS Code",
      url: "https://cs50.dev/",
      favicon: "./ui-elements/vscode.png"
    },
    {
      label: "W3Schools HTML",
      url: "https://www.w3schools.com/html/",
      favicon: "./ui-elements/w3schools.png"
    },
    {
      label: "W3Schools CSS",
      url: "https://www.w3schools.com/css/",
      favicon: "./ui-elements/w3schools.png"
    },
    {
      label: "W3Schools JS",
      url: "https://www.w3schools.com/js/",
      favicon: "./ui-elements/w3schools.png"
    },
    {
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/home",
      favicon: "./ui-elements/cs50-edx.png"
    }
  ],
  instruction: "<h3>Week 8</h3><ul><li>Cybersecurity Overview</li><li>Cybersecurity Lecture</li><li>Overview</li><li>Lecture</li><li>Section</li><li>Shorts</li><li>Lab 8</li><li>Problem Set<ul><li>Homepage</li></ul></li></ul>"
},
{
  weekNumber: 9,
  weekLabel: "Flask",
  content: [{
      label: "Overview",
      progressID: 64,
      requiredProgress: 63,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@c7937ee528344aefbedb3628638940bb/block-v1:HarvardX+CS50+X+type@vertical+block@53df817830294add8cc1536f26494a43"
    },
    {
      label: "Lecture ",
      progressID: 65,
      requiredProgress: 64,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@c7937ee528344aefbedb3628638940bb/block-v1:HarvardX+CS50+X+type@vertical+block@503ac0214edd44618d5e6eb4b4c178d6"
    },
    {
      label: "Section",
      progressID: 66,
      requiredProgress: 65,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@c7937ee528344aefbedb3628638940bb/block-v1:HarvardX+CS50+X+type@vertical+block@2d90ecf7a2b6409db01ac3be6f48a5d3"
    },
    {
      label: "Shorts",
      progressID: 67,
      requiredProgress: 66,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@c7937ee528344aefbedb3628638940bb/block-v1:HarvardX+CS50+X+type@vertical+block@efea819002e641baab6074ce67b54249"
    },
    {
      label: "Lab 9",
      progressID: 68,
      requiredProgress: 67,
      url: "https://cs50.harvard.edu/x/2023/labs/9/"
    },
    {
      label: "Finance",
      progressID: 69,
      requiredProgress: 68,
      url: "https://cs50.harvard.edu/x/2023/psets/9/finance/"
    },
  ],
  bookmarks: [{
      label: "CS50x Homepage",
      url: "https://cs50.harvard.edu/x/2023/",
      favicon: "./ui-elements/harvard-logo.png"
    },
    {
      label: "CS50x Gradebook",
      url: "https://cs50.me/cs50x",
      favicon: "./ui-elements/harvard-logo.png"
    },
    {
      label: "VS Code",
      url: "https://cs50.dev/",
      favicon: "./ui-elements/vscode.png"
    },
    {
      label: "W3Schools HTML",
      url: "https://www.w3schools.com/html/",
      favicon: "./ui-elements/w3schools.png"
    },
    {
      label: "W3Schools CSS",
      url: "https://www.w3schools.com/css/",
      favicon: "./ui-elements/w3schools.png"
    },
    {
      label: "W3Schools JavaScript",
      url: "https://www.w3schools.com/js/",
      favicon: "./ui-elements/w3schools.png"
    },
    {
      label: "W3Schools Python",
      url: "https://www.w3schools.com/python/",
      favicon: "./ui-elements/w3schools.png"
    },
    {
      label: "Jinja Documentation",
      url: "https://jinja.palletsprojects.com/en/3.1.x/",
      favicon: "./ui-elements/jinja-logo.png"
    },
    {
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/home",
      favicon: "./ui-elements/cs50-edx.png"
    }
  ],
  instruction: "<h3>Week 9</h3><ul><li>Overview</li><li>Lecture</li><li>Section</li><li>Shorts</li><li>Lab 9</li><li>Problem Set<ul><li>Finance</li></ul></li></ul>",
},
{
  weekNumber: 10,
  weekLabel: "Emoji",
  content: [{
      label: "Overview",
      progressID: 70,
      requiredProgress: 69,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@5f830906ea764494ad216f3b2a4b9669/block-v1:HarvardX+CS50+X+type@vertical+block@e7b0a40138a9474a8142d816ceb9a9e1"
    },
    {
      label: "Lecture ",
      progressID: 71,
      requiredProgress: 70,
      url: "https://learning.edx.org/course/course-v1:HarvardX+CS50+X/block-v1:HarvardX+CS50+X+type@sequential+block@5f830906ea764494ad216f3b2a4b9669/block-v1:HarvardX+CS50+X+type@vertical+block@3d19181be7c64b979fadb6df1c9298cf"
    },
    {
      label: "Final Project",
      progressID: 72,
      requiredProgress: 71,
      url: "https://cs50.harvard.edu/x/2023/project/"
    },
    {
      label: "Submit Final Project",
      progressID: 73,
      requiredProgress: 72,
      url: "https://www.youtube.com/watch?v=3GwjfUFyY6M"
    },
  ],
  bookmarks: [{
      label: "CS50x Homepage",
      url: "https://cs50.harvard.edu/x/2023/",
      favicon: "./ui-elements/harvard-logo.png"
    },
    {
      label: "CS50x Gradebook",
      url: "https://cs50.me/cs50x",
      favicon: "./ui-elements/harvard-logo.png"
    },
    {
      label: "VS Code",
      url: "https://cs50.dev/",
      favicon: "./ui-elements/vscode.png"
    },
    {
      label: "CS50 Final Project",
      url: "https://cs50.harvard.edu/x/2023/project/",
      favicon: "./ui-elements/harvard-logo.png"
    },
  ],
  instruction: "<h3>Week 10</h3><ul><li>Overview</li><li>Lecture</li><li>Final Project</li></ul>",
},
];